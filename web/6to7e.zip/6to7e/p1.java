class A
{
	public static void main(String b[])
	{
		System.out.print("ABC");
	}
}