class A
{
	public static void main(String bb[])
	{
	}
}
