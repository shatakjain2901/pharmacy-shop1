class Student
{
	String name;
}
class A
{
	public static void main(String[] ar)
	{
		int y=10;
		f1(y);
		System.out.println("After Calling:"+y);
		Student s1=new Student();
		s1.name="Abhay";
		f2(s1);
		System.out.println("After Calling:"+s1.name);
	}
	static void f1(int a)
	{
		System.out.println("Recvd:"+a);
		a=100;
		System.out.println("After Changed:"+a);
	}
	static void f2(Student s)
	{
		System.out.println("Recvd:"+s.name);
		s.name="Rajat";
		System.out.println("After Changed:"+s.name);
	}
}