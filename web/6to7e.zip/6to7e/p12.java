class Student
{
	String name;
}
class A
{
	public static void main(String[] ar)
	{
		A a1=new A();
		int y=10;
		a1.f1(y);
		System.out.println("After Calling:"+y);
		Student s1=new Student();
		s1.name="Abhay";
		a1.f2(s1);
		System.out.println("After Calling:"+s1.name);
	}
	void f1(int a)
	{
		System.out.println("Recvd:"+a);
		a=100;
		System.out.println("After Changed:"+a);
	}
	void f2(Student s)
	{
		System.out.println("Recvd:"+s.name);
		s.name="Rajat";
		System.out.println("After Changed:"+s.name);
	}
}