class Student
{
	String name;
}
class A
{
	public static void main(String[] ar)
	{
		int x=f1();
		Student s1=f2();
		System.out.println(x);
		System.out.println(s1.name);
	}
	static int f1()
	{
		int x=56;
		return x;
	}
	static Student f2()
	{
		Student s=new Student();
		s.name="Abhay";
		return s;
	}
}