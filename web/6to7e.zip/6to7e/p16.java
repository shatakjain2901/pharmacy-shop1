import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Your Name:");
		String s1=sc.next();
		System.out.print("Enter Your Age:");
		int x=sc.nextInt();
		System.out.print("Enter Your Salary:");
		double y=sc.nextDouble();
		System.out.println("Name:"+s1);
		System.out.println("Age:"+x);
		System.out.println("Salary:"+y);
	}
}