import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		int x;
		System.out.print("Enter a Number:");
		x=sc.nextInt();
		for(int i=1;i<=10;i++)
		{
			System.out.println(x+"x"+i+"="+x*i);
		}
	}
}