import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.print("Enter total elements:");
		n=sc.nextInt();
		int a=0,b=1,c=a+b;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		for(int i=1;i<=n-3;i++)
		{
			a=b;
			b=c;
			c=a+b;
			System.out.println(c);
		}
	}
}