class A
{
	public static void main(String b[])
	{
		System.out.print("ABC 1");
	}
}
class B
{
	public static void main(String b[])
	{
		System.out.print("ABC 2");
	}
}
class C
{
	static void main(String b[])
	{
		System.out.print("ABC");
	}
}
class D
{
	public void main(String b[])
	{
		System.out.print("ABC");
	}
}
class E
{
}