import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a Value:");
		double d=sc.nextDouble();
		d=Math.toRadians(d);
		double d1=Math.sin(d);
		System.out.println(d1);
	}
}