import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		for(int i=1;i<=10;i++)
		{
			double d=Math.random();
			//System.out.println(d);
			d=d*110+40;
			System.out.println(d);
		}
	}
}