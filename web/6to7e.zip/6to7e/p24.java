import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter 1st String:");
		String s1=sc.next();
		System.out.print("Enter 2nd String:");
		String s2=sc.next();
		//if(s1==s2)
		if(s1.equals(s2))
			System.out.println("Same");
		else
			System.out.println("different");

	}
}