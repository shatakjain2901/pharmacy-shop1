import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		String s="A Quick Brown Fox Jumps over the Lazy Dog";
		int s1=s.length();
		String s2=s.toLowerCase();
		String s3=s.toUpperCase();
		char s4=s.charAt(10);
		String s5=s.substring(10);
		String s6=s.substring(10,21);
		System.out.println(s);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
		System.out.println(s5);
		System.out.println(s6);
	}
}
