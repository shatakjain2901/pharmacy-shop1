import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		String s="A Quick Brown Fox Jumps over the Lazy Dog";
		int p=s.indexOf("o");
		while(p>=0)
		{
			System.out.println(p);
			p=s.indexOf("o",p+1);
		}
	}
}
