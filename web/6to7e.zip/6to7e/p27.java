import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		String s="A Quick Brown Fox Jumps over the Lazy Dog";
		String[] arr=s.split("o");
		for(String item:arr)
		{
			System.out.println(item);
		}
	}
}
