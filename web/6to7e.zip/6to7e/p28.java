import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a string:");
		String s1=sc.next();
		System.out.print("Enter 2nd string:");
		String s2=sc.next();
		System.out.println(s1.startsWith(s2));
	}
}

