class B
{
	{
		System.out.println("A");
	}
	static
	{
		System.out.println("B");
	}
}
class A
{
	public static void main(String b[])
	{
		B b1=new B();
		B b2=new B();
		B b3=new B();
		B b4=new B();
	}
}
