import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		String s="Example of string functions and data";
		String s1=s.replace("i","ABC");
		String s2=s1.replace("a","ABC");
		System.out.println(s2);
	}
}

