import java.io.Console;
class A
{
	public static void main(String[] ar)
	{
		Console con=System.console();
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
			con.readLine();
		}
	}
}

