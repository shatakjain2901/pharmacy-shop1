import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		int[] y=new int[10];
		for(int i=0;i<y.length;i++)
		{
			y[i]=sc.nextInt();
		}
		System.out.println();
		for(int item:y)
		{
			System.out.println(item);
		}
	}
}

