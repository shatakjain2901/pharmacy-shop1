import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		System.out.println("Length is "+ar.length);
		for(String item:ar)
		{
			System.out.println(item);
		}
	}
}

