import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		int[][] x={{1,2,3,4},
		{1,2,3,4,5,6,7,8,9},
		{1,2,34,5,6,67}};

		System.out.println(x.length);
		System.out.println(x[0].length);
		System.out.println(x[1].length);
		System.out.println(x[2].length);
		System.out.println();
		for(int i=0;i<x.length;i++)
		{
			System.out.println();
			for(int j=0;j<x[i].length;j++)
			{
				System.out.print(x[i][j]+"  ");
			}
		}
		System.out.println();
		for(int[] y:x)
		{
			System.out.println();
			for(int item:y)
			{
				System.out.print(item+"  ");
			}
		}
	}
}

