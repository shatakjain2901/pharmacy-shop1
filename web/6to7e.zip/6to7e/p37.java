import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		int[][] x=new int[4][];
		x[0]=new int[5];
		x[1]=new int[8];
		x[2]=new int[3];
		x[3]=new int[5];
		System.out.println("Enter 21 Values:");
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x[i].length;j++)
			{
				x[i][j]=sc.nextInt();
			}
		}
		System.out.println();
		for(int[] y:x)
		{
			System.out.println();
			for(int item:y)
			{
				System.out.print(item+"  ");
			}
		}
	}
}

