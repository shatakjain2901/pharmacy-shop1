import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		int[][] x=new int[4][5];
		System.out.println("Enter Matrix:");
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x[i].length;j++)
			{
				x[i][j]=sc.nextInt();
			}
		}
		System.out.println("Matrix:");
		System.out.println();
		for(int[] y:x)
		{
			System.out.println();
			for(int item:y)
			{
				System.out.print(item+"  ");
			}
		}
		System.out.println("\nTranspose:");
		for(int i=0;i<5;i++)
		{
			System.out.println();
			for(int j=0;j<4;j++)
			{
				System.out.print(x[j][i]+"   ");
			}
		}
	}
}

