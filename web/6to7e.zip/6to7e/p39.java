import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		String s="Example Of String DATA";
		String[] arr=s.split(" ");
		System.out.println("Total Words:"+arr.length);
		String s1="";
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(c>=65 && c<=90)
			{
				c=(char)(c+32);
			}
			else if(c>=97 && c<=123)
			{
				c=(char)(c-32);
			}
			s1=s1+c;
		}
		System.out.println(s1);
	}
}

