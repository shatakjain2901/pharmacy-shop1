class A
{
	public static void main(String b[])
	{
		float x=234.56F;
		double y=423.7;
		long z=3000000000L;
		System.out.print("ABC 1\n");
		System.out.println("ABC 2");
		System.out.println();
		System.out.println(45);
		System.out.println(54.67);
		System.out.println('A');
		System.out.println(56*10+52);
		System.out.print("ABC 3\n");
		System.out.println("x");
		System.out.println(x);
	}
}
