import java.util.Scanner;
class A
{
	public static void main(String[] ar)
	{
		int[] arr={34,7,98,45,12,54,678,90,56,23,12,36};
		for(int i=0;i<arr.length;i++)
		{
			int min=arr[i];
			int k=i;
			for(int j=i;j<arr.length;j++)
			{
				if(min>arr[j])
				{
					min=arr[j];
					k=j;
				}
			}
			int t=arr[i];
			arr[i]=arr[k];
			arr[k]=t;
		}
		System.out.println("Sorted Elements are:");
		for(int item:arr)
		{
			System.out.print(item+"  ");
		}
	}
}

