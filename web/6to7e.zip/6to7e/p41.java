import java.util.*;
class A
{
	public static void main(String[] ar)
	{
		int[] arr={34,7,98,45,12,54,678,90,56,23,12,36};
		Arrays.sort(arr);
		System.out.println("Sorted Elements are:");
		for(int item:arr)
		{
			System.out.print(item+"  ");
		}
	}
}

