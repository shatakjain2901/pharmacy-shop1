class p42
{
	public static void main(String[] ar)
	{
			System.out.println(Integer.MAX_VALUE);
			System.out.println(Integer.MIN_VALUE);
			System.out.println(Double.MAX_VALUE);
	}
}

