class A
{
}
class B
{
	B(int a)
	{

	}
	void f1()
	{
	}
}
class C
{
	int x;
	static int y;
	void f1()
	{
	}
}
class p43
{
	public static void main(String[] ar)
	{
	}
}

