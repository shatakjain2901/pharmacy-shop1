class A
{
	public String toString()
	{
		return "Hello";
	}
}
class p44
{
	public static void main(String[] ar)
	{
		A a1=new A();
		A a2=new A();
		A a3=new A();
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
	}
}

