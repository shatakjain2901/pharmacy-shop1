interface A
{
	int x=23;
	void f1();
	void f2();
}
class p45
{
	public static void main(String[] ar)
	{

	}
}

