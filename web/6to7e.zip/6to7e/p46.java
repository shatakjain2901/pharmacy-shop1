class A
{
}
abstract class B
{
}
interface C
{

}
class p46
{
	public static void main(String[] ar)
	{
		A a=new A();
		B b=new B();
		C c=new C();
	}
}

