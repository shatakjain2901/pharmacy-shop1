class A
{
	A()
	{
		System.out.println("ABC");
	}
}
class B extends A
{
	B()
	{
		System.out.println("X");
	}
}
class p47
{
	public static void main(String[] ar)
	{
		B b=new B();
	}
}

