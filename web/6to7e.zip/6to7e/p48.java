class Student
{
	void f1()
	{
		System.out.println("Hello Student");
	}
}
class p48
{
	public static void main(String[] ar)
	{
		Student s=new Student();
		s.f1();
	}
}

