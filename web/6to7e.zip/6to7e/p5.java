class A
{
	public static void main(String b[])
	{
		float x=234.56F;
		double y=423.7;
		long z=3000000000L;
		System.out.println("ABC"+"XYZ");
		System.out.println("ABC"+567);
		System.out.println("ABC"+52.25);
		System.out.println("x="+x);
		System.out.println("y="+y);
		System.out.println("z="+z);
		System.out.println();
		int w=20;
		for(int i=1;i<=10;i++)
		{
			System.out.println(w+"x"+i+"="+w*i);
		}
	}
}
