class A
{
	void f1()
	{
		System.out.println("Zero Parameter");
	}
	void f1(int a)
	{
		System.out.println("1 Integer Parameter");
	}
	void f1(double b)
	{
		System.out.println("1 Double Parameter");
	}
	void f1(float b)
	{
		System.out.println("1 Float Parameter");
	}
}
class p50
{
	public static void main(String[] ar)
	{
		byte x1=23;
		short x2=23;
		int x3=23;
		long x4=23;
		float x5=23.45F;
		double x6=23.45;
		String x7="ABC";
		boolean x8=true;
		char x9='A';
		A a=new A();
		a.f1();
		a.f1(x1);
		a.f1(x2);
		a.f1(x3);
		a.f1(x4);
		a.f1(x5);
		a.f1(x6);
		//a.f1(x7);
		//a.f1(x8);
		a.f1(x9);
	}
}
