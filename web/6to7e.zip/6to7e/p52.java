class A
{
	A()
	{
		System.out.println("Blank Constructor");
	}
	A(int a)
	{
		System.out.println("1 Integer Constructor");
	}
}
class p52
{
	public static void main(String[] ar)
	{
		A a1=new A();
		A a2=new A(34);
		//A a3=new A(456.678);
	}
}

