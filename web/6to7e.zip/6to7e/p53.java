class Person
{
	String name;
}
class Emp extends Person
{
	int salary;
}
class p53
{
	public static void main(String[] ar)
	{
		Emp e=new Emp();
		e.name="ABC";
		e.salary=15000;
		System.out.println(e.name);
		System.out.println(e.salary);
		Person p;
		p=e;
		System.out.println();
		System.out.println(p.name);
		System.out.println(p.salary); //Error
	}
}

