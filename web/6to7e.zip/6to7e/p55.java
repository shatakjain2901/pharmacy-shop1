class Person
{
	String name;
}
class Emp extends Person
{
	int salary;
}
class Student extends Person
{
	String course;
}
class p54
{
	public static void main(String[] ar)
	{
		Emp e=new Emp();
		e.name="Mr. Yogesh";
		e.salary=25000;
		Student s=new Student();
		s.name="Rajat Kumar";
		s.course="MBA";
		print(s);
		print(e);
	}
	static void print(Object p)
	{
		System.out.println(p.name);
		//System.out.println(p.salary);		 Error
		//System.out.println(p.course);		 Error
		if(p instanceof Student)
		{
			Student s1=(Student)p;
			System.out.println(s1.course);
		}
		else
		{
			Emp e1=(Emp)p;
			System.out.println(e1.salary);
		}
	}
}

