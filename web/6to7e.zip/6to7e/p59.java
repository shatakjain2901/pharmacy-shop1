final class A
{
}
class B extends A // Error
{
}
class C
{
	final void f1()
	{
	}
}
class D extends C
{
	void f1()		// Error
	{
	}
}
class p59
{
	public static void main(String[] ar)
	{

	}
}


