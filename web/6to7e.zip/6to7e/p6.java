class A
{
	public static void main(String bb[])
	{
		int a=100;
		int b=170;
		int c=270;
		byte x1,x2,x3;
		x1=(byte)a;
		x2=(byte)b;
		x3=(byte)c;
		System.out.println(x1);
		System.out.println(x2);
		System.out.println(x3);
	}
}
