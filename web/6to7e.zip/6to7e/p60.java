class A
{
	void f1()
	{
		System.out.println("F1 in A");
	}
}
class B extends A
{
	void f1()
	{
		System.out.println("F1 in B");
	}
	void f2()
	{
		f1();
		super.f1();
	}
}
class p60
{
	public static void main(String[] ar)
	{
		B b=new B();
		b.f2();
	}
}


