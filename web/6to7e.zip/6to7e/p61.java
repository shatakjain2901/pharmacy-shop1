class A
{
	A()
	{
		System.out.println("Zero Parameter in A");
	}
	A(int a)
	{
		System.out.println("Integer in A");
	}
	A(String a)
	{
		System.out.println("String in A");
	}
}
class B extends A
{
	B()
	{
		super("ABC");
		System.out.println("Blank in B");
	}
	B(int y)
	{
		super(y);
		System.out.println("Integer in B");
	}
	B(String s1,String s2)
	{
		super(s1);
		System.out.println("Two String in B");
	}
}
class p61
{
	public static void main(String[] ar)
	{
		B b1=new B();
		B b2=new B(546);
		B b3=new B("ABC","FGFG");
	}
}


