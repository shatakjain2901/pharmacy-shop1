class Person
{
	String name;
	Person(String nm)
	{
		name=nm;
	}
	void print()
	{
		System.out.println("Name:"+name);
	}
}
class Emp extends Person
{
	int salary;
	Emp(String n,int s)
	{
		super(n);
		salary=s;
	}
	void print()
	{
		super.print();
		System.out.println("Salary:"+salary);
	}
}
class Student extends Person
{
	String course;
	Student(String n,String c)
	{
		super(n);
		course=c;
	}
	void print()
	{
		super.print();
		System.out.println("Course:"+course);
	}
}

class p62
{
	public static void main(String[] ar)
	{
		Person p1,p2;
		p1=new Student("Aman","MBA");
		p2=new Emp("Ravi Kumar",15000);
		p1.print();
		p2.print();
	}
}


