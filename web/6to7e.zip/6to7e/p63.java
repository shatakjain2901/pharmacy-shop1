class p63
{
	public static void main(String[] ar)
	{
		f1();
	}
	static void f1()
	{
		f1();
		int x=234;
	}
}


