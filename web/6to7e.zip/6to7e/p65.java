import java.util.Scanner;
class p65
{
	public static void main(String[] ar)
	{
		Scanner sc=new Scanner(System.in);
		int[] arr={3425,6789,234,4576,7890,345};
		int ans=0;
		System.out.print("Array Index:");
		try{
			int i=sc.nextInt();
			System.out.print("Value:");
			int x=sc.nextInt();
			ans=arr[i]/x;
		}catch(ArrayIndexOutOfBoundsException ee)
		{
			System.out.println("Array Index Problem");
		}catch(ArithmeticException ee)
		{
			System.out.println("Second value can't be zero");
		}
		System.out.println("Answer is :"+ans);
	}
}



