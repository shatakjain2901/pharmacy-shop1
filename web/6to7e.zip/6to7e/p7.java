class A
{
	public static void main(String bb[])
	{
		int x=2000000000;
		int y=2000000000;
		long z2=x+(long)y;
		System.out.println(z2);
	}
}
