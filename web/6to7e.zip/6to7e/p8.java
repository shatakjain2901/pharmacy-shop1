class Student
{
	String name;
	static String college;
	static void f1()
	{
		//System.out.println(name);
		System.out.println(college);
	}
	void f2()
	{
		System.out.println(name);
		System.out.println(college);
	}
}
class A
{
	public static void main(String bb[])
	{
		//Student.name="A";
		Student.college="ABC";
		Student.f1();
		//Student.f2();
		Student s1=new Student();
		Student s2=new Student();
		Student s3=new Student();
		s1.name="A1";
		s2.name="A2";
		s3.name="A3";
		s1.f2();
		s2.f2();
		s3.f2();
		s1.college="AABBCC";
		System.out.println(s2.college);
	}
}
