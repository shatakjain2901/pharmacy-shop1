class A
{
	int x;
	static int y;
	public static void main(String bb[])
	{
		int z; // local variable
		System.out.println(y);
		//System.out.println(x);
		A a=new A();
		System.out.println(a.x);
		z=60;	// initialization is compulsory before use, local var.
		System.out.println(z);
	}
}
